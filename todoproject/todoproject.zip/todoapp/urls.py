from django.conf.urls.static import static
from django.urls import path

from todoproject import settings
from . import views

urlpatterns = [

    path('',views.home,name='home'),
    path('delete/<int:taskid>/',views.delete,name='delete'),
    path('update/<int:taskid>/',views.update,name='update')
]
